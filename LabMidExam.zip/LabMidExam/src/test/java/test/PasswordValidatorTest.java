/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

/**
 *
 * @author user
 */

import model.PasswordValidator;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PasswordValidatorTest {

    // Positive Test
    @Test
    void shouldAcceptValidPassword() {

        PasswordValidator validator =
                new PasswordValidator();

        assertTrue(
                validator.isValid("Password123")
        );

    }
    // Negative Test
    @Test
    void shouldRejectShortPassword() {

        PasswordValidator validator =
                new PasswordValidator();

        assertFalse(
                validator.isValid("abc")
        );

    }

}
