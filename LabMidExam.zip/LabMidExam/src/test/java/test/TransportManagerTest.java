package test;
import model.Bus;
import model.Student;
import model.TransportManager;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class TransportManagerTest {
    @Test
    void shouldAssignBusToStudent() {
        TransportManager manager =
                new TransportManager();
        Student student =
                new Student(
                        "Ali",
                        "S001"
                );
        Bus bus =
                new Bus(
                        "BUS-101",
                        "Route A"
                );
        manager.assignBus(
                student,
                bus
        );
        assertEquals(
                bus,
                student.getBus()
        );
    }
}
