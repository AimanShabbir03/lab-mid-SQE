/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author user
 */


import java.util.ArrayList;

public class StudentManager {

    private ArrayList<Student> students =
            new ArrayList<>();

    public void registerStudent(
            Student student) {

        students.add(student);

    }

    public ArrayList<Student> getStudents() {

        return students;

    }

}
