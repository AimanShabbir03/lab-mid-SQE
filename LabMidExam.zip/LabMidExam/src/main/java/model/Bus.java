package model;

public class Bus {

    private String busNo;
    private String route;

    public Bus(
            String busNo,
            String route) {

        this.busNo = busNo;
        this.route = route;

    }

    public String getBusNo() {
        return busNo;
    }

    public String getRoute() {
        return route;
    }

}