package model;
public class Student {
    private String name;
    private String studentId;
    private Bus bus;
    public Student(
            String name,
            String studentId) {
        this.name = name;
        this.studentId = studentId;

    }
    public String getName() {
        return name;
    }

    public String getStudentId() {
        return studentId;
    }

    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }

}