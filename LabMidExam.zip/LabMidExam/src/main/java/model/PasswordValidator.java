/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author user
 */


public class PasswordValidator {

    public boolean isValid(String password) {

        if (password == null) {
            return false;
        }

        return password.length() >= 8;

    }

}
