/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author user
 */


public class TransportManager {

    public void assignBus(
            Student student,
            Bus bus) {

        student.setBus(bus);

    }

}
